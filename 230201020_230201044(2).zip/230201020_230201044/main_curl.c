#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <curl/curl.h>

//global degiskenlerim
int count =0;
int numara; //kullanicidan girdi icin alinacak numara
const char *urls[10];//senaryo urlleri
int insan_tur = 1;
int ork_tur = 1;
int ybir = 1;// insan saldiri yorgunluk icin
int p = 1; //piyade kritik sans icin
int o = 1; //okcu kritik sans icin
int s = 1; //suvari kritik sans icin
int k = 1; //kusatma makineleri kritik sans icin
int or = 1;//ork dovuscusu kritik sans icin
int m = 1; //mizrakcilar kritik sans icin
int v = 1; //varg binicileri kritik sans icin
int t = 1; //troller kritik sans icin
int y2 = 1; //insan savunma yorgunluk icin
int y3 = 1; //ork saldiri yorgunluk icin
int y4 = 1; //ork savunma yorgunluk icin
int h1 = 1; //yavuz sultan selim icin
int h2 = 1; //vrog kafakiran icin
int c1 = 1;//karakurt icin
int e1 = 1; //elit egitim icin insan
int e2 = 1; //eliit egitim hocam insan
int e3 = 1; //elit egitim icin insan
int e4 = 1; //elit egitim icin ork
int e5 = 1; //elit egitim icin ork
int e6 = 1; //elit egitim icin ork

struct InsanImparatorlugu {
    char kahraman[50];
    char canavar[30];
    char arastirma[30];
    float okcular;
    float piyadeler;
    float kusatma_makineleri;
    float suvariler;
    int arastirma_degeri;
};

struct OrkLegi {
    char kahraman[50];
    char canavar[30];
    char arastirma[30];
    float mizrakcilar;
    float orkDovuscileri;
    float troller;
    float vargBinicileri;
    int  arastirma_degeri;
};

struct Unit {
    char name[50];
    float saldiri;
    float savunma;
    float saglik;
    float kritik_sans;
};

struct Unit units[8];

struct Creature {
    char name[50];
    char etki_degeri[10];
    char etki_turu[20];
    char aciklama[50];
};

 struct Creature creatures[11];

struct Hero{
    char name[50];
    char bonus_turu[20];
    char bonus_degeri[20];
    char aciklama[50];
};

struct Hero heroes[9];

struct Research {
    char name[50];
    char deger[10];
    char aciklama[50];
};

struct Research researchs[12];

struct Hasar_dagilimi {
    float piyade_hasar;
    float okcu_hasar;
    float kusatma_hasar;
    float suvari_hasar;
    float orkDovuscusu_hasar;
    float mizrakci_hasar;
    float troller_hasar;
    float vargBinicisi_hasar;
};

struct Hasar_dagilimi hasar;

struct Savunma 
{
    float piyade_oran;
    float okcu_oran;
    float kusatma_oran;
    float suvari_oran;
    float orkDovuscusu_oran;
    float mizrakci_oran;
    float troller_oran;
    float vargBinicisi_oran;
};

struct Savunma oran;

void parseInsanImparatorlugu(const char* jsonString, struct InsanImparatorlugu *insan) {
    const char *insanSection = strstr(jsonString, "\"insan_imparatorlugu\": {");
    if (insanSection) {
        insanSection += strlen("\"insan_imparatorlugu\": {");

        // Kahraman
        const char *kahramanStart = strstr(insanSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", insan->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(insanSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", insan->canavar);
        }

        const char *arastirmaSeviyesiStart = strstr(insanSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
             sscanf(arastirmaSeviyesiStart, " \"%[^\"]\": ", insan->arastirma);
            if(strcmp(insan->arastirma,"savunma_ustaligi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &insan->arastirma_degeri);
                
            }

            if(strcmp(insan->arastirma,"saldiri_gelistirmesi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &insan->arastirma_degeri);
                
            }

            if(strcmp(insan->arastirma,"elit_egitim") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &insan->arastirma_degeri);
                
            }

            if(strcmp(insan->arastirma,"kusatma_ustaligi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &insan->arastirma_degeri);
              
            }
        }


       // Birimler
const char *birimlerStart = strstr(insanSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");

    char  *okcuStart,*piyadeStart, *kusatmaStart, *suvariStart;

    // Okçular
    okcuStart = strstr(birimlerStart, "\"okcular\":");
    if(okcuStart){
        sscanf(okcuStart, " \"okcular\": %f,", &insan->okcular);
    }

    piyadeStart = strstr(birimlerStart, "\"piyadeler\":");
    if (piyadeStart) {
        sscanf(piyadeStart, " \"piyadeler\": %f,", &insan->piyadeler);
    }


    kusatmaStart = strstr(birimlerStart, "\"kusatma_makineleri\":");
    if (kusatmaStart) {
        sscanf(kusatmaStart, " \"kusatma_makineleri\": %f,", &insan->kusatma_makineleri);
    }


    suvariStart = strstr(birimlerStart, "\"suvariler\":");
    if (suvariStart) {
        sscanf(suvariStart, " \"suvariler\": %f,", &insan->suvariler);
    }
}

    }

}


void parseOrkLegi(const char* jsonString, struct OrkLegi *ork) {
    const char *orkSection = strstr(jsonString, "\"ork_legi\": {");
    if (orkSection) {
        orkSection += strlen("\"ork_legi\": {");

        // Kahraman
        const char *kahramanStart = strstr(orkSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", ork->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(orkSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", ork->canavar);
        }

        const char *arastirmaSeviyesiStart = strstr(orkSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
            sscanf(arastirmaSeviyesiStart, " \"%[^\"]\": ", ork->arastirma);
            if(strcmp(ork->arastirma,"savunma_ustaligi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &ork->arastirma_degeri);
                
            }
            if(strcmp(ork->arastirma,"saldiri_gelistirmesi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &ork->arastirma_degeri);
                
            }
            if(strcmp(ork->arastirma,"elit_egitim") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &ork->arastirma_degeri);
                
            }
            if(strcmp(ork->arastirma,"kusatma_ustaligi") == 0)
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &ork->arastirma_degeri);
               
            }
        }
       // Birimler
const char *birimlerStart = strstr(orkSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");

    char *mizrakStart, *orkDovuscileriStart, *trollerStart, *vargStart;

    mizrakStart = strstr(birimlerStart, "\"mizrakcilar\":");
    if(mizrakStart){
    sscanf(mizrakStart, " \"mizrakcilar\": %f,", &ork->mizrakcilar);}

    orkDovuscileriStart = strstr(birimlerStart, "\"ork_dovusculeri\":");
    if (orkDovuscileriStart) {
        sscanf(orkDovuscileriStart, " \"ork_dovusculeri\": %f,", &ork->orkDovuscileri);
    }


    trollerStart = strstr(birimlerStart, "\"troller\":");
    if (trollerStart) {
        sscanf(trollerStart, " \"troller\": %f,", &ork->troller);
    }

    vargStart = strstr(birimlerStart, "\"varg_binicileri\":");
    if (vargStart) {
        sscanf(vargStart, " \"varg_binicileri\": %f,", &ork->vargBinicileri);
    }
}

   


    }
}

void set_default_values( struct Unit *unit) {
    unit->saldiri = 0;
    unit->savunma = 0;
    unit->saglik = 0;
    unit->kritik_sans = 0;
}



int read_json(const char *filename,struct Unit *units) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Hata: Dosya '%s' bulunamadi.Lutfen dosyanin doğru isimde ve doğru dizinde olduğundan emin olun.", filename);

        return -1;
    }
    char line[400];
    int unit_count = 0;
    struct Unit current_unit;
    set_default_values(&current_unit);

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0; 

        if (strstr(line, "{")) {
            sscanf(line, " \"%[^\"]\": {", current_unit.name);
            set_default_values(&current_unit);
        } else if (strstr(line, "saldiri")) {
            sscanf(line, " \"saldiri\": %f,", &current_unit.saldiri);
        } else if (strstr(line, "savunma")) {
            sscanf(line, " \"savunma\": %f,", &current_unit.savunma);
        } else if (strstr(line, "saglik")) {
            sscanf(line, " \"saglik\": %f,", &current_unit.saglik);
        } else if (strstr(line, "kritik_sans")) {
            sscanf(line, " \"kritik_sans\": %f,", &current_unit.kritik_sans);
        } else if (strstr(line, "}"))
        {
            if(!(count == 4) && !( count == 9))
            {
                if(unit_count < 8)
                {
                    units[unit_count] = current_unit;
                    unit_count++;
                }
            }
            count++;
        }
    }
    count = 0;
    fclose(file);
    return 0;
}


int hero_json(const char *filename1,struct Hero *heroes) {
    FILE *file1 = fopen(filename1, "r");
    if (!file1) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename1);
        return -1;
    }

    char line_hero[400];
    struct Hero current_unith;
    int hero_count = 0;

    while (fgets(line_hero, sizeof(line_hero), file1)) {
        line_hero[strcspn(line_hero, "\n")] = 0;

        if (strstr(line_hero, "{")) {
            sscanf(line_hero, " \"%[^\"]\": {", current_unith.name);
        } else if (strstr(line_hero, "bonus_turu")) {
            sscanf(line_hero, " \"bonus_turu\": \"%[^\"]\",", current_unith.bonus_turu);
        } else if (strstr(line_hero, "bonus_degeri")) {
            sscanf(line_hero, " \"bonus_degeri\": \"%[^\"]\",", current_unith.bonus_degeri);
        } else if (strstr(line_hero, "aciklama")) {
            sscanf(line_hero, " \"aciklama\": \"%[^\"]\",", current_unith.aciklama);
        } else if (strstr(line_hero, "}")) {

            if( !(count == 4) )
            {
                if (hero_count < 9)
                 {
                     heroes[hero_count++] = current_unith;
                 }
            }
            count++;
        }
    }
    count = 0;
    fclose(file1);
    return 0;
}


int creatures_json(const char *filename2,struct Creature *creatures) {
    FILE *file2 = fopen(filename2, "r");
    if (!file2) {
        printf("Hata: Dosya '%s' bulunamadi.Lutfen dosyanin dogru dizinde ve dogru isimde oldugundan emin olun", filename2);
        return -1;
    }

    char line_c[400];
    int creature_count = 0;
    struct Creature current_unitc;

    while (fgets(line_c, sizeof(line_c), file2)) {
        line_c[strcspn(line_c, "\n")] = 0;

        if (strstr(line_c, "{")) {
            sscanf(line_c, " \"%[^\"]\": {", current_unitc.name);
        } else if (strstr(line_c, "etki_degeri")) {
            sscanf(line_c, " \"etki_degeri\": \"%[^\"]\",", current_unitc.etki_degeri);
        } else if (strstr(line_c, "etki_turu")) {
            sscanf(line_c, " \"etki_turu\": \"%[^\"]\",", current_unitc.etki_turu);
        } else if (strstr(line_c, "aciklama")) {
            sscanf(line_c, " \"aciklama\": \"%[^\"]\",", current_unitc.aciklama);
        } else if (strstr(line_c, "}")) {
            if(!(count == 4))

            {
                if (creature_count < 11)
                {
                     creatures[creature_count++] = current_unitc;
                }
            }
            count++;
        }
    }
    count = 0;
    fclose(file2);
    return 0;
}


int research_json(const char *filename3,struct Research *researchs) {
    FILE *file3 = fopen(filename3, "r");
    if (!file3) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename3);
        return -1;
    }

    char line_r[400];
    int researchs_count = 0;
    struct Research current_unitr;

    while (fgets(line_r, sizeof(line_r), file3)) {
        line_r[strcspn(line_r, "\n")] = 0;

        if (strstr(line_r, "{")) {
            sscanf(line_r, " \"%[^\"]\": {", current_unitr.name);
        } else if (strstr(line_r, "deger")) {
            sscanf(line_r, " \"deger\": \"%[^\"]\",", current_unitr.deger);
        } else if (strstr(line_r, "aciklama")) {
            sscanf(line_r, " \"aciklama\": \"%[^\"]\",", current_unitr.aciklama);
        } else if (strstr(line_r, "}")) {

            if( !(count ==3) && !(count ==7) && !(count ==11))
            {

            if (researchs_count < 12) {
                researchs[researchs_count] = current_unitr;
                researchs_count++;
            }

            }
            count++;
        }
    }
    count = 0;
    fclose(file3);
    return 0;
}


float saldiri_insan( struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs, int tur)
{




    

    float net_saldiri,piyade_saldiri,kusatma_saldiri,suvari_saldiri,okcu_saldiri;

    //yorgunluk hesaplaması icin
    if(tur == 5*ybir)
    {
        units->saldiri *= (1-0.1);
        (units + 1)->saldiri *= (1-0.1);
        (units + 2)->saldiri *= (1-0.1);
        (units + 3)->saldiri *= (1-0.1);
        ybir++;
        
    }
    
    // her bir birimin kritik sansida var bu yuzden her bir birim icin kritik sans hesaplamasi yaptim
    if(tur == (100 / (units->kritik_sans))*p)
    {
     units->saldiri *= 1.50;
        p++;
    }
 
    if(tur == (100 / (units + 1)->kritik_sans)*o)
    {
        (units + 1)->saldiri *= 1.50;
        o++;
    }
    if(tur == (100 / (units + 2)->kritik_sans)*s)
    {
        (units + 2)->saldiri *= 1.50;
        s++;
    }
    if(tur == (100 / (units + 3)->kritik_sans)*k)
    {
        (units + 3)->saldiri *= 1.50;
        k++;
    }
    if((strcmp(insan->kahraman,"Fatih_Sultan_Mehmet")==0) && tur ==1)
    {
        (units+3)->saldiri *=((atof((heroes+1)->bonus_degeri)+100)/100);//kusatmamakinesi
    }
    if((strcmp(insan->kahraman,"Tugrul_Bey")==0) && tur ==1)
    {
        (units + 1)->saldiri *=((atof((heroes+4)->bonus_degeri)+100)/100); //okcu
    }

    //yavuz sultan selim kritik sansda etkili
    if((strcmp(insan-> kahraman,"Yavuz_Sultan_Selim"))==0)
    {

        if(tur == (100 / atof((heroes + 3)->bonus_degeri))*h1)
        {
            (units + 2)->saldiri *= 1.50; //suvari
            h1++;
        }

    }
   if((strcmp(insan->canavar,"Ejderha")==0) && tur == 1)
    {
        units->saldiri *= ((atof(creatures->etki_degeri)+100)/100);  //piyade
    }
   
    if((strcmp(insan->canavar,"Tepegoz")==0) && tur == 1)
    {
        (units + 1 )->saldiri *= ((atof((creatures + 2)->etki_degeri)+100)/100); //okcu
    }

     if((strcmp(insan->canavar,"Karakurt")==0) && tur == (100 / atof((creatures + 3)->etki_degeri)*c1))
    {
        (units + 1 )->saldiri *= 1.50;
        c1++;
    }
    if(strcmp(insan->arastirma,"saldiri_gelistirmesi")==0 && tur == 1)
    {
        if(insan->arastirma_degeri == 1)
        {
             units->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 1)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 2)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 3)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);


        }
        else if(insan->arastirma_degeri == 2)
        {
            units->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 1)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 2)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 3)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
        }
        else if(insan->arastirma_degeri == 3)
        {
            units->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 1)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 2)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 3)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
        }

        if(strcmp(insan->arastirma,"elit_egitim")==0 && tur == 1)
        {
            if(insan->arastirma_degeri == 1 && tur == (100 / atoi((researchs + 6)->deger))*e1)
            {
                units->saldiri *= 1.50;
                (units + 1)->saldiri *= 1.50;
                (units + 2)->saldiri *= 1.50;
                (units + 3)->saldiri *= 1.50;
                e1++;
            }
            else if(insan->arastirma_degeri == 2 && tur == (100 / atoi((researchs + 7)->deger))*e2)
            {
                units->saldiri *= 1.50;
                (units + 1)->saldiri *= 1.50;
                (units + 2)->saldiri *= 1.50;
                (units + 3)->saldiri *= 1.50;
                e2++;
            }
            else if(insan->arastirma_degeri == 3 && tur == (100 / atoi((researchs + 8)->deger))*e3)
            {
                units->saldiri *= 1.50;
                (units + 1)->saldiri *= 1.50;
                (units + 2)->saldiri *= 1.50;
                (units + 3)->saldiri *= 1.50;
                e3++;
            }
        }

        if(strcmp(insan->arastirma,"kusatma_ustaligi")==0 && tur == 1) //kusatma ustalalarina saldiri bonusu veriyor sadece
        {
            if(insan->arastirma_degeri == 1)
            {
                (units + 3)->saldiri *= ((atof((researchs + 9)->deger)+100)/100);
            }
            else if(insan->arastirma_degeri == 2)
            {
                (units + 3)->saldiri *= ((atof((researchs + 10)->deger)+100)/100);
            }
            else if(insan->arastirma_degeri == 3)
            {
                (units + 3)->saldiri *= ((atof((researchs + 11)->deger)+100)/100);
            }

        }


    }

   
    piyade_saldiri = (units->saldiri) * (insan->piyadeler);
    
    kusatma_saldiri = (units + 3)->saldiri * (insan->kusatma_makineleri);

    suvari_saldiri = (units + 2)->saldiri * (insan->suvariler);
   
    okcu_saldiri = (units + 1)->saldiri * (insan->okcular);
    
    net_saldiri = piyade_saldiri + kusatma_saldiri + suvari_saldiri + okcu_saldiri;

    return net_saldiri;
}


float savunma_insan( struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs,int tur,struct Savunma *oran )
{


    float net_savunma,piyade_savunma,kusatma_savunma,suvari_savunma,okcu_savunma;


    if(tur % (5*y2) == 0)
    {
        units->savunma *= (1-0.1);
        (units + 1)->savunma *=  (1-0.1);
        (units + 2)->savunma *=  (1-0.1);
        (units + 3)->savunma *=  (1-0.1);
        y2++;
    }



    if((strcmp(insan->kahraman,"Alparslan")==0) && tur ==1)
    {
        units->savunma *= ((atof(heroes -> bonus_degeri)+100)/100);  //piyade
    }
    if((strcmp(insan->kahraman,"Mete_Han")==0) && tur ==1)
    {
        (units + 1)->savunma *= ((atof((heroes + 2) -> bonus_degeri)+100)/100); //okcu
    }
   if((strcmp(insan->canavar,"Agri_Dagi_Devleri")==0 && tur ==1))
    {
       (units + 2)->savunma *= ((atof((creatures + 1)-> etki_degeri)+100)/100);   //suvariler
    }
    if((strcmp(insan->canavar,"Samur")==0) && tur == 1)
    {
         units->savunma *= ((atof((creatures + 4)-> etki_degeri)+100)/100);  //piyade
    }

    if(strcmp(insan->arastirma,"savunma_ustaligi") ==0 && tur == 1)
    {
        if(insan->arastirma_degeri == 1)
        {
             units->savunma *= ((atof(researchs->deger)+100)/100);
            (units + 1)->savunma *=((atof(researchs->deger)+100)/100);
            (units + 2)->savunma *= ((atof(researchs->deger)+100)/100);
            (units + 3)->savunma *= ((atof(researchs->deger)+100)/100);
        }
       else if(insan->arastirma_degeri == 2)
        {
            units->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 1)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 2)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 3)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
        }
        else if(insan->arastirma_degeri == 3)
        {
            units->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 1)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 2)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 3)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
        }
    }



    piyade_savunma = (units->savunma) * (insan->piyadeler);
    kusatma_savunma = (units + 3)->savunma * (insan->kusatma_makineleri);
    suvari_savunma = (units + 2)->savunma * (insan->suvariler);
    okcu_savunma = (units + 1)->savunma * (insan->okcular);
    net_savunma = piyade_savunma + kusatma_savunma + suvari_savunma + okcu_savunma;
     if(net_savunma < 0)
    {
        net_savunma = 0;
    }
    oran->piyade_oran = piyade_savunma / net_savunma;
    oran->kusatma_oran = kusatma_savunma / net_savunma;
    oran->suvari_oran = suvari_savunma / net_savunma;
    oran->okcu_oran = okcu_savunma / net_savunma;
    return net_savunma;
}


float saldiri_ork( struct OrkLegi *ork, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs,int tur )
{


    float net_saldiri, mizrak_saldiri, orkDovuscileri_saldiri, troller_saldiri, varg_saldiri;


    //yorgunluk icin
    if(tur % (5*y3) == 0)
    {
        (units + 4)->saldiri *= (1-0.1);
        (units + 5)->saldiri *= (1-0.1);
        (units + 6)->saldiri *= (1-0.1);
        (units + 7)->saldiri *= (1-0.1);
        y3++;
    }
    //her bir birimin kritik sansi var bu yuzden her bir birim icin kritik sans hesaplamasi yaptim
    if(tur == (100 / (units + 4)->kritik_sans)*or)
    {
        (units + 4)->saldiri *= 1.50;
        or++;
    }
    if(tur == (100 / (units + 5)->kritik_sans)*m)
    {
        (units + 5)->saldiri *= 1.50;
        m++;
    }
    if(tur == (100 / (units + 6)->kritik_sans)*v)
    {
        (units + 6)->saldiri *= 1.50;
        v++;
    }
    if(tur == (100 / (units + 7)->kritik_sans)*t)
    {
        (units + 7)->saldiri *= 1.50;
        t++;
    }
    if((strcmp(ork->kahraman,"Goruk_Vahsi") ==0) && tur == 1)
    {
        (units + 4)->saldiri *= ((atof((heroes + 5) -> bonus_degeri)+100)/100);  //orkdovuscusu
    }
    if((strcmp(ork->kahraman,"Vrog_Kafakiran") ==0 ))
    {

        if(tur == (100 / atof((heroes + 7) -> bonus_degeri))*h2)
        {
             (units + 6)->saldiri *= 1.50; //vargbinicisi
             h2++;
        }

    }
   if((strcmp(ork->canavar,"Kara_Troll")==0) && tur == 1)
    {
        (units + 7)->saldiri *= ((atof((creatures + 5) -> etki_degeri)+100)/100); //troller
    }
    if((strcmp(ork->canavar,"Ates_Iblisi")==0) && tur == 1)
    {
        (units + 6)->saldiri *= ((atof((creatures + 8) -> etki_degeri)+100)/100); //vargbinicisi
    }
    if(strcmp(ork->arastirma,"saldiri_gelistirmesi")==0 && tur == 1)
    {
        if((ork->arastirma_degeri) == 1)
        {
            (units + 4)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 5)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 6)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);
            (units + 7)->saldiri *= ((atof((researchs + 3)->deger)+100)/100);


        }
        else if((ork->arastirma_degeri) == 2)
        {
            ((units + 4)->saldiri) *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 5)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 6)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
            (units + 7)->saldiri *= ((atof((researchs + 4)->deger)+100)/100);
        }
        else if(ork->arastirma_degeri == 3)
        {
            (units + 4)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 5)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 6)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
            (units + 7)->saldiri *= ((atof((researchs + 5)->deger)+100)/100);
        }


    }
    if(strcmp(ork->arastirma,"elit_egitim")==0 && tur == 1)
    {
        if(ork->arastirma_degeri == 1 && tur ==(100 / atof((researchs + 6)->deger))*e4)
        {

            (units + 4)->saldiri *= 1.50;
            (units + 5)->saldiri *= 1.50;
            (units + 6)->saldiri *= 1.50;
            (units + 7)->saldiri *= 1.50;
            e4++;
        }
        else if(ork->arastirma_degeri == 2 && tur ==(100 / atof((researchs + 7)->deger))*e5)
        {

            (units + 4)->saldiri *= 1.50;
            (units + 5)->saldiri *= 1.50;
            (units + 6)->saldiri *= 1.50;
            (units + 7)->saldiri *= 1.50;

        }
        else if(ork->arastirma_degeri == 3 && tur ==(100 / atof((researchs + 8)->deger))*e6)
        {

            (units + 4)->saldiri *= 1.50;
            (units + 5)->saldiri *= 1.50;
            (units + 6)->saldiri *= 1.50;
            (units + 7)->saldiri *= 1.50;

        }
    }



    mizrak_saldiri = (units + 5)->saldiri * (ork->mizrakcilar);
    orkDovuscileri_saldiri = (units + 4)->saldiri * (ork->orkDovuscileri);
    troller_saldiri = (units + 7)->saldiri * (ork->troller);
    varg_saldiri = (units + 6)->saldiri * (ork->vargBinicileri);
    net_saldiri = mizrak_saldiri + orkDovuscileri_saldiri + troller_saldiri + varg_saldiri;

    return net_saldiri;
}


float savunma_ork( struct OrkLegi *ork, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs,int tur,struct Savunma *oran )
{


    float net_savunma, mizrak_savunma, orkDovuscileri_savunma, troller_savunma, varg_savunma;


    if(tur % (5*y4) == 0)
    {
        (units + 4)->savunma *= (1-0.1);
        (units + 5)->savunma *= (1-0.1);
        (units + 6)->savunma *= (1-0.1);
        (units + 7)->savunma *= (1-0.1);
        y4++;
    }

    if((strcmp(ork->kahraman,"Thruk_Kemikkiran")==0) && tur == 1)
    {
        (units + 7)->savunma *= ((atof((heroes + 6) -> bonus_degeri)+100)/100);  //troller
    }
    if((strcmp(ork->kahraman,"Ugar_Zalim")==0) && tur == 1)
    {
        (units + 7)->savunma *= ((atof((heroes + 8) -> bonus_degeri)+100)/100);
        (units + 6)->savunma *= ((atof((heroes + 8) -> bonus_degeri)+100)/100);
        (units + 5)->savunma *= ((atof((heroes + 8) -> bonus_degeri)+100)/100);
        (units + 4)->savunma *= ((atof((heroes + 8) -> bonus_degeri)+100)/100);
    }
   if((strcmp(ork->canavar,"Golge_Kurtlari")==0)  && tur == 1)
    {
        (units + 6)->savunma *= ((atof((creatures + 6) -> etki_degeri)+100)/100);//vargbinicisi
    }
    if((strcmp(ork->canavar,"Camur_Devleri")==0) && tur == 1)
    {
         (units + 4)->savunma *= ((atof((creatures + 7) -> etki_degeri)+100)/100);  //orkdovuscusu
    }
    if((strcmp(ork->canavar,"Makrog_Savas_Beyi")==0) && tur == 1)
    {
        (units + 7)->savunma *= ((atof((creatures + 9) -> etki_degeri)+100)/100); //troller
    }
    if((strcmp(ork->canavar,"Buz_Devleri")==0) && tur == 1)
    {
        (units + 5)->savunma *= ((atof((creatures + 10) -> etki_degeri)+100)/100); //mizrakcilar
    }

    if(strcmp(ork->arastirma,"savunma_ustaligi")==0 && tur == 1)
    {
        if(ork->arastirma_degeri == 1)
        {
            (units + 4)->savunma *= ((atof(researchs->deger)+100)/100);
            (units + 5)->savunma *= ((atof(researchs->deger)+100)/100);
            (units + 6)->savunma *= ((atof(researchs->deger)+100)/100);
            (units + 7)->savunma *= ((atof(researchs->deger)+100)/100);
        }
       else if(ork->arastirma_degeri == 2)
        {
            (units + 4)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 5)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 6)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
            (units + 7)->savunma *= ((atof((researchs + 1)->deger)+100)/100);
        }
        else if(ork->arastirma_degeri == 3)
        {
            (units + 4)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 5)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 6)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
            (units + 7)->savunma *= ((atof((researchs + 2)->deger)+100)/100);
        }

    }



    mizrak_savunma = (units + 5)->savunma * (ork->mizrakcilar);
    orkDovuscileri_savunma = (units + 4)->savunma * (ork->orkDovuscileri);
    troller_savunma = (units + 7)->savunma * (ork->troller);
    varg_savunma = (units + 6)->savunma * (ork->vargBinicileri);
    net_savunma = mizrak_savunma + orkDovuscileri_savunma + troller_savunma + varg_savunma;
    if(net_savunma < 0)
    {
        net_savunma = 0;
    }
    oran->mizrakci_oran = mizrak_savunma / net_savunma;
    oran->orkDovuscusu_oran = orkDovuscileri_savunma / net_savunma;
    oran->troller_oran = troller_savunma / net_savunma;
    oran->vargBinicisi_oran = varg_savunma / net_savunma;
    return net_savunma;
}

void hasar_dagilimi_insan(struct Hasar_dagilimi *hasar,int net_hasar, struct Savunma *oran)
{
    hasar->piyade_hasar = net_hasar * (oran->piyade_oran);
    hasar->okcu_hasar = net_hasar * (oran->okcu_oran);
    hasar->suvari_hasar = net_hasar * (oran->suvari_oran);
    hasar->kusatma_hasar = net_hasar * (oran->kusatma_oran);
}

void hasar_dagilimi_ork(struct Hasar_dagilimi *hasar,int net_hasar, struct Savunma *oran)
{
    hasar->mizrakci_hasar = net_hasar * (oran->mizrakci_oran);
   
    hasar->orkDovuscusu_hasar = net_hasar * (oran->orkDovuscusu_oran);
    
    hasar->troller_hasar = net_hasar * (oran->troller_oran);
    
    hasar->vargBinicisi_hasar = net_hasar * (oran->vargBinicisi_oran);
   
}

void insan_saglik(struct InsanImparatorlugu *insan, struct Unit *units,struct Hasar_dagilimi *hasar)
{
    if(units->saglik > 0)
    {
        units->saglik = units->saglik - ( hasar ->piyade_hasar / insan->piyadeler);
        if(units->saglik < 0)
        {
            units->saglik = 0;
        }
    }
    if((units + 1)->saglik > 0)
    {
        (units + 1)->saglik = (units + 1)->saglik - ( hasar ->okcu_hasar / insan->okcular);
        if((units + 1)->saglik < 0)
        {
            (units + 1)->saglik = 0;
        }
    }
    if((units + 2)->saglik > 0)
    {
        (units + 2)->saglik = (units + 2)->saglik - ( hasar ->suvari_hasar / insan->suvariler);
        if((units + 2)->saglik < 0)
        {
            (units + 2)->saglik = 0;
        }
    }
    if((units + 3)->saglik > 0)
    {
        (units + 3)->saglik = (units + 3)->saglik - (hasar ->kusatma_hasar / insan->kusatma_makineleri);
        if((units + 3)->saglik < 0)
        {
            (units + 3)->saglik = 0;
    }
}
}
void ork_saglik(struct OrkLegi *ork, struct Unit *units, struct Hasar_dagilimi *hasar)
{
    if((units + 4)->saglik > 0)
    {
        (units + 4)->saglik = (units + 4)->saglik - (hasar ->orkDovuscusu_hasar / ork->orkDovuscileri);
        if((units + 4)->saglik < 0)
        {
            (units + 4)->saglik = 0;
        }
    }
    if((units + 5)->saglik > 0)
    {
        (units + 5)->saglik = (units + 5)->saglik - (hasar ->mizrakci_hasar / ork->mizrakcilar);
        if((units + 5)->saglik < 0)
        {
            (units + 5)->saglik = 0;
        }
    }
    if((units + 6)->saglik > 0)
    {
        (units + 6)->saglik = (units + 6)->saglik - (hasar ->vargBinicisi_hasar / ork->vargBinicileri);
        if((units + 6)->saglik < 0)
        {
            (units + 6)->saglik = 0;
        }
    }
    if((units + 7)->saglik > 0)
    {
        (units + 7)->saglik = (units + 7)->saglik - (hasar -> troller_hasar / ork->troller);
        if((units + 7)->saglik < 0)
        {
            (units + 7)->saglik = 0;
        }
    }
}

// Yazma işlemi
int write_wartxt(const char *filename4, struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes,struct OrkLegi *ork,struct Creature *creatures,struct Research *researchs,struct Savunma *oran,struct Hasar_dagilimi *hasar) {
    FILE *file4 = fopen(filename4, "w");
    if (!file4) {
        printf("Hata: Dosya '%s' bulunamadi.\n", filename4);
        return -1;
    }

    int yeni;
    int tur;
    float saldiri_sonuc_insan;
    float saldiri_sonuc_ork;
    float savunma_sonuc_insan;
    float savunma_sonuc_ork;
    float net_hasar_ork;
    float net_hasar_insan;
    float saglik;
    
    for(tur=1 ;tur <= 10000 ; tur++)
    {
           
            if(tur % 2 ==1)
            {

            
               if(units->saglik <= 0 )
               {
                    insan->piyadeler = 0;
               }
               if((units + 1)->saglik <= 0 )
                {
                     insan->okcular = 0;
                }
                if((units + 2)->saglik <= 0 )
                {
                      insan->suvariler = 0;
                }
                if((units + 3)->saglik <= 0 )
                {
                     insan->kusatma_makineleri = 0;
                }

                if( ((units->saglik) > 0 ) || ((units + 1)->saglik > 0) || ((units + 2)->saglik > 0) || ((units + 3)->saglik > 0) )
                {
                    fprintf(file4,"\n%d. Adim:\n", tur);
                    saldiri_sonuc_insan = saldiri_insan(insan,units,heroes,creatures,researchs,insan_tur);
                    if(saldiri_sonuc_insan < 0)
                    {
                        saldiri_sonuc_insan = 0;
                    }
                    savunma_sonuc_ork = savunma_ork(ork,units,heroes,creatures,researchs,insan_tur,oran);
                    net_hasar_ork= saldiri_sonuc_insan *(1.0-(savunma_sonuc_ork/saldiri_sonuc_insan));
                    if(net_hasar_ork < 0)
                    {
                        net_hasar_ork = 0;
                    }
                    hasar_dagilimi_ork(hasar,net_hasar_ork,oran);
                   if(ork->troller == 0)
                    {
                        (units + 7)->saglik = 0;
                    }
                    if(ork->orkDovuscileri == 0)
                    {
                        (units + 4)->saglik = 0;
                    }
                    if(ork->mizrakcilar == 0)
                    {
                        (units + 5)->saglik = 0;
                    }
                    if(ork->vargBinicileri == 0)
                    {
                        (units + 6)->saglik = 0;
                    }
                   ork_saglik(ork,units,hasar);
                    fprintf(file4,"toplam Saldiri Sonucu: %.2f\n", saldiri_sonuc_insan);
                    fprintf(file4,"toplam Savunma Sonucu: %.2f\n", savunma_sonuc_ork);
                    fprintf(file4,"net hasar ork: %.2f\n", net_hasar_ork);
                    fprintf(file4,"mizrakci sayisi %.2f\n",ork->mizrakcilar);
                    fprintf(file4,"orkdovuscusu sayisi %.2f\n",ork->orkDovuscileri);
                    fprintf(file4,"troller sayisi %.2f\n",ork->troller);
                    fprintf(file4,"varg sayisi %.2f\n",ork->vargBinicileri);
                    fprintf(file4,"hasar dagilimi mizrakci : %.2f\n",hasar->mizrakci_hasar);
                    fprintf(file4,"hasar dagilimi ork dovuscusu : %.2f\n",hasar->orkDovuscusu_hasar);
                    fprintf(file4,"hasar dagilimi troller : %.2f\n",hasar->troller_hasar);
                    fprintf(file4,"hasar dagilimi varg : %.2f\n",hasar->vargBinicisi_hasar);
                    fprintf(file4,"saglik mizrakci : %.2f\n",(units + 5)->saglik);
                    fprintf(file4,"saglik ork dovuscusu : %.2f\n",(units + 4)->saglik);
                    fprintf(file4,"saglik troller : %.2f\n",(units + 7)->saglik);
                    fprintf(file4,"saglik varg : %.2f\n",(units + 6)->saglik);
                }
                
                else
               
                {
                    fputs("\nInsan irkindan hicbir birim kalmadi.ork kazandi",file4);
                    break;
                }
                   insan_tur++;

            }
          else if(tur % 2 == 0)
           {
           

            if((units + 4)->saglik <= 0 )
            {
                ork->orkDovuscileri = 0;
            }
            if((units + 5)->saglik <= 0 )
            {
                ork->mizrakcilar = 0;
            }
            if((units + 6)->saglik <= 0 )
            {
                ork->vargBinicileri = 0;
            }
            if((units + 7)->saglik <= 0 )
            {
                ork->troller = 0;
            }

            if( ((units + 4)->saglik > 0 ) || ((units + 5)->saglik > 0) || ((units + 6)->saglik > 0) || ((units + 7)->saglik > 0) )
            {
                 fprintf(file4,"\n%d. Adim:\n", tur);
                saldiri_sonuc_ork = saldiri_ork(ork,units,heroes,creatures,researchs,ork_tur);
                savunma_sonuc_insan = savunma_insan(insan,units,heroes,creatures,researchs,ork_tur,oran);
                net_hasar_insan= saldiri_sonuc_ork *(1-(savunma_sonuc_insan/saldiri_sonuc_ork));
                if(net_hasar_insan < 0)
                {
                    net_hasar_insan = 0;
                }
                hasar_dagilimi_insan(hasar,net_hasar_insan,oran);
                if(insan->piyadeler == 0)
                {
                    units->saglik = 0;
                }
                if(insan->okcular == 0)
                {
                    (units + 1)->saglik = 0;
                }
                if(insan->suvariler == 0)
                {
                    (units + 2)->saglik = 0;
                }
                if(insan->kusatma_makineleri == 0)
                {
                    (units + 3)->saglik = 0;
                }
                insan_saglik(insan,units,hasar);
                fprintf(file4,"toplam Saldiri Sonucu: %.2f\n", saldiri_sonuc_ork);
                fprintf(file4,"toplam Savunma Sonucu: %.2f\n", savunma_sonuc_insan);
                fprintf(file4,"net hasar insan: %.2f\n", net_hasar_insan);
                fprintf(file4,"okcu sayisi %.2f\n",insan->okcular);
                fprintf(file4,"piyade sayisi %.2f\n",insan->piyadeler);
                fprintf(file4,"suvari sayisi %.2f\n",insan->suvariler);
                fprintf(file4,"kusatma sayisi %.2f\n",insan->kusatma_makineleri);
                fprintf(file4,"hasar dagilimi piyade : %.2f\n",hasar->piyade_hasar);
                fprintf(file4,"hasar dagilimi okcu : %.2f\n",hasar->okcu_hasar);
                fprintf(file4,"hasar dagilimi suvari : %.2f\n",hasar->suvari_hasar);
                fprintf(file4,"hasar dagilimi kusatma : %.2f\n",hasar->kusatma_hasar);
                fprintf(file4,"saglik piyade : %.2f\n",units->saglik);
                fprintf(file4,"saglik okcu : %.2f\n",(units + 1)->saglik);
                fprintf(file4,"saglik suvari : %.2f\n",(units + 2)->saglik);
                fprintf(file4,"saglik kusatma : %.2f\n",(units + 3)->saglik);
               

            }

            
             else
            {
                 fputs("\nOrk irkindan hicbir birim kalmadi.insan kazandi",file4);
                
                break;
            }
            ork_tur++;

    printf("\n");
    }
    
    }

    printf("savas_sim.txt dosyasini kontrol ediniz, adimlar oradadir \n");
    fclose(file4);
    printf("Dosyaya yazdirma islemi basarili oldu.\n");
    return 0;
}



// Senaryo URL'leri
const char *urls[10] = {
    "https://yapbenzet.org.tr/1.json",
    "https://yapbenzet.org.tr/2.json",
    "https://yapbenzet.org.tr/3.json",
    "https://yapbenzet.org.tr/4.json",
    "https://yapbenzet.org.tr/5.json",
    "https://yapbenzet.org.tr/6.json",
    "https://yapbenzet.org.tr/7.json",
    "https://yapbenzet.org.tr/8.json",
    "https://yapbenzet.org.tr/9.json",
    "https://yapbenzet.org.tr/10.json"
};


struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, struct MemoryStruct *mem) {
    size_t realsize = size * nmemb;
    mem->memory = realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        printf("Yetersiz bellek!\n");
        return 0;
    }
    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0; 
    return realsize;
}


void download_scenario(const char *url, const char *output_filename) {
    CURL *curl;
    CURLcode res;
    struct MemoryStruct chunk;

    chunk.memory = malloc(1);
    chunk.size = 0; 

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "libcurl-agent/1.0");

        res = curl_easy_perform(curl);
        if(res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() hata: %s\n", curl_easy_strerror(res));
        } else {
            FILE *file = fopen(output_filename, "wb");
            if (file) {
                fwrite(chunk.memory, sizeof(char), chunk.size, file);
                fclose(file);
                printf("Indirilen senaryo '%s' dosyasina yazildi.\n", output_filename);
            } else {
                fprintf(stderr, "Dosya acilamadi: %s\n", output_filename);
            }
        }
        curl_easy_cleanup(curl);
        free(chunk.memory);
    }
    curl_global_cleanup();
}

int main() {


    struct Unit units[8];
    struct InsanImparatorlugu insan;
    struct Hero heroes[9];
    struct OrkLegi ork;
    struct Creature creatures[11];
    struct Research researchs[12];
    struct Savunma oran;
    struct Hasar_dagilimi hasar;

    const char *filename = "Files/unit_types.json";
    const char *filename1 = "Files/heroes.json";
    const char *filename2 = "Files/creatures.json";
    const char *filename3 = "Files/research.json";
    const char *filename4 = "savas_sim.txt";
    const char *url;
    const char *output_filename = "indirilen_senaryo.json";

    printf("Lutfen 1 ile 10 arasinda bir numara girin: ");
    scanf("%d", &numara);
    if (numara < 1 || numara > 10) {
        printf("Geçersiz numara. Lütfen 1 ile 10 arasinda bir numara girin.\n");
        return 1;
    }

    if(numara == 1)
    {
        url = urls[0];
    }
    else if(numara == 2)
    {
        url = urls[1];
    }
    else if(numara == 3)
    {
        url = urls[2];
    }
    else if(numara == 4)
    {
        url = urls[3];
    }
    else if(numara == 5)
    {
        url = urls[4];
    }
    else if(numara == 6)
    {
        url = urls[5];
    }
    else if(numara == 7)
    {
        url = urls[6];
    }
    else if(numara == 8)
    {
        url = urls[7];
    }
    else if(numara == 9)
    {
        url = urls[8];
    }
    else if(numara == 10)
    {
        url = urls[9];
    }
    download_scenario(url, output_filename);

    if (read_json(filename,units) == 0) {
    printf("unit_types.json okuma islemi basarili oldu.\n");
    }
    else
    {
        printf("unit_types.json okuma islemi basarisiz oldu.\n");
    }


if(hero_json(filename1,heroes) == 0) {
    printf("heroes.json okuma islemi basarili oldu.\n");
    }
    else
    {
        printf("heroes.json okuma islemi basarisiz oldu.\n");
    }

if(creatures_json(filename2,creatures) == 0) {
    printf(" creatures.json okuma islemi basarili oldu.\n");
    }
    else
    {
        printf("creatures.json okuma islemi basarisiz oldu.\n");
    }

if(research_json(filename3,researchs) == 0) {
    printf("research.json okuma islemi basarili oldu.\n");
    }
    else
    {
        printf("research.json okuma islemi basarisiz oldu.\n");
    }

    FILE *file = fopen("indirilen_senaryo.json", "r");
    if (!file) {
        printf("indirilen_senaryo.json okuma basarisiz oldu");
        return -1;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);
    char *jsonString = malloc(length + 1);
    fread(jsonString, 1, length, file);
    fclose(file);
    jsonString[length] = '\0';


    memset(&insan, 0, sizeof(insan));
    parseInsanImparatorlugu(jsonString, &insan);

    memset(&ork, 0, sizeof(ork));
    parseOrkLegi(jsonString, &ork);


    if(write_wartxt(filename4,&insan,units,heroes,&ork,creatures,researchs,&oran,&hasar)==0)
    {
        printf("Dosya olusturuldu ve icerigi yazildi.\n");
    }
    else
    {
        printf("Dosya olusturulamadi.\n");
    }
    return 0;

}
